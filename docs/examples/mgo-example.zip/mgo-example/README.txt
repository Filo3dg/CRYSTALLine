MgO — a worked example for CRYSTALLine
======================================

Two small CRYSTAL calculations on magnesium oxide, enough to try every part of
the program. Keep each folder as it is: CRYSTALLine looks for a run's other
files beside the output it was given.

properties/
    mgo.out                  SCF on the primitive cell (B3LYP)
    mgo_band.BAND            the band structure it produced
    mgo_band.d3              the deck that asked for it — this is where the
                             names of the path's corners come from
    mgo_doss_totalao.DOSS    the density of states, from the same SCF
    mgo_doss_totalao.d3      the deck that asked for that

    Open mgo.out. The Info panel names the space group (Fm-3m, No. 225).
    Plot -> Electronic bands & DOS finds both data files by reading them, pairs
    them because they carry the same Fermi level, and labels the path
    Gamma-X-W-L-Gamma from the deck.

phonons/
    mgo_222_disp.out         a frequency calculation with DISPERSI, giving
                             modes at eight q points of a 2x2x2 supercell

    Open it and the Phonons panel lists the q points. Choose one away from
    Gamma, pick a mode, and press Play: it is animated as a travelling wave.
    "Tile" repeats the cell over one wavelength.

Both runs are from the MSSC and QMMC schools. They are here to be opened, not
to be cited.
